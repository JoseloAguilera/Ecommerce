<footer class="main-footer">
	<div class="pull-right hidden-xs">
		<b>Version</b> 1.1.0
	</div>
	<strong>Copyright &copy; 2020 <a href=""><?php echo $_SESSION['empresa'];?></a>.</strong> All rights
	reserved.
</footer>