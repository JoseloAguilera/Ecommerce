<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

<!-- Bootstrap -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<!-- Bootstrap Toggle -->
<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
<!-- Font Awesome -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">



<!-- Theme style -->
<link rel="stylesheet" href="css/AdminLTE.min.css">
<!-- AdminLTE Skins -->
<link rel="stylesheet" href="css/skin-yellow.min.css">

<!-- bootstrap selectpicker -->
<link rel="stylesheet" href="plugins/bootstrap-select/dist/css/bootstrap-select.min.css">

<!-- bootstrap colorpicker -->
<link rel="stylesheet" href="plugins/bootstrap-colorpicker/dist/css/bootstrap-colorpicker.min.css">

<!-- daterange picker -->
<script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />

<!-- Datatables >
<link rel="stylesheet" type="text/css" href="plugins/DataTables/datatables.min.css"/-->
<link rel="stylesheet" type="text/css" href="plugins/DataTables/DataTables-1.10.20/css/dataTables.bootstrap.css"/>
<link rel="stylesheet" type="text/css" href="plugins/DataTables/DataTables-1.10.20/buttons.dataTables.min.css"/>

<!-- Datapicker -->
<!-- <link rel="stylesheet" type="text/css" href="plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css"/>
<link rel="stylesheet" type="text/css" href="plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css"/> -->
<link rel="stylesheet" type="text/css" href="plugins/bootstrap-datepicker/css/bootstrap-datepicker.standalone.min.css"/>
<link rel="stylesheet" type="text/css" href="plugins/bootstrap-datepicker/css/bootstrap-datepicker3.standalone.min.css"/>

<!-- Select2 -->
<link rel="stylesheet" href="plugins/select2/dist/css/select2.min.css">

<!-- switch button -->
<link href="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/css/bootstrap4-toggle.min.css" rel="stylesheet">

<!-- Meus Estilos -->
<link rel="stylesheet" href="css/select2-alt.css">
<link rel="stylesheet" href="css/estilos.css">
<link rel="shortcut icon" href="../img/favicon.ico" />

<!-- FONTS -->