
<?php
	include_once "mods/server/pedido.php";

	$pedidos = getAllPedidos();
?>