<!-- Caja de Texto de color gris (Default) -->
<div class="box">
	<!-- Corpo de Caja -->
	<div class="box-body text-center">
		<img src="img/logo.jpg" class="img-circle" alt="Logo Image" style="max-width: 200px;">
		<h3>Página em manutenção!</h3><br><h4>Aguarde para maiores informações</h4>
	</div>	<!-- /.box-body -->
</div> <!-- /.Caja de Texto de color gris (Default) -->